require(['jquery','owl-carousel'], function ($) {

/*===== Document Ready =======*/
jQuery(document).ready(function (){   

   jQuery('.mainbanner').each(function(){   
            jQuery(this).owlCarousel({
            loop:true,
            items: 1,
            nav : false,
            dots:false,
            margin:0, 
            responsive:{   
                0:{ 
                    dots: (jQuery(this).find('.item').length > 1) ? true : false,
                    mouseDrag: (jQuery(this).find('.item').length > 1) ? true : false,
                    loop: (jQuery(this).find('.item').length > 1) ? true : false
                }  
            } 
        }); 
       }); 

      }); 
	 
 }); 