var config = {
    paths: {
        'owl-carousel': 'js/owl.carousel' 
       //'isotope-pkgd': 'js/isotope.pkgd' 
       /*  'masonry-pkgd-min': 'js/masonry.pkgd.min'  */ 
    },
    shim: {
        'owl-carousel': {
            deps: ['jquery'] 
        }/*,
        'isotope-pkgd': {
            deps: ['jquery'] 
        },
       
        'fancybox' : 
        {
            deps: ['jquery'] 
        },
        'customupdatecart' : 
        {
            deps: ['jquery'] 
        }*/
	} 
};
 